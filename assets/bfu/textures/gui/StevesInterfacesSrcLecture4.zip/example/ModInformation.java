package example;

public class ModInformation {

	public static final String ID = "StevesInterfaces";
	public static final String NAME = "Steve's Interfaces";
	public static final String VERSION = "Lecture 4";
	public static final String CHANNEL = "example";
	
}
