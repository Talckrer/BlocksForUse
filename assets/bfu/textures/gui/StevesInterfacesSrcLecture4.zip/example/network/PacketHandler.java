package example.network;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.network.INetworkManager;
import net.minecraft.network.packet.Packet250CustomPayload;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteStreams;

import cpw.mods.fml.common.network.IPacketHandler;
import cpw.mods.fml.common.network.PacketDispatcher;
import cpw.mods.fml.common.network.Player;
import example.ModInformation;
import example.client.interfaces.ContainerMachine;
import example.entities.EntitySpaceship;
import example.tileentities.TileEntityMachine;

public class PacketHandler implements IPacketHandler {

	@Override
	public void onPacketData(INetworkManager manager, Packet250CustomPayload packet, Player player) {
		ByteArrayDataInput reader = ByteStreams.newDataInput(packet.data);
		
		EntityPlayer entityPlayer = (EntityPlayer)player;
		
		byte packetId = reader.readByte();
		
		switch (packetId) {
			case 0:
				int entityId = reader.readInt();
		
				
				Entity entity = entityPlayer.worldObj.getEntityByID(entityId);
				if (entity != null && entity instanceof EntitySpaceship && entity.riddenByEntity == entityPlayer) {
					((EntitySpaceship)entity).doDrop();
				}			
				break;
			case 1:
				byte type = reader.readByte();
				byte val = reader.readByte();
				Container container = entityPlayer.openContainer;
				if (container != null && container instanceof ContainerMachine) {
					TileEntityMachine machine = ((ContainerMachine)container).getMachine();
					machine.receiveInterfaceEvent(type, val);
				}
				break;
		}
		

	}

	public static void sendShipPacket(EntitySpaceship ship) {
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		DataOutputStream dataStream = new DataOutputStream(byteStream);

		try {
			dataStream.writeByte((byte)0);
			dataStream.writeInt(ship.entityId);			
			
			PacketDispatcher.sendPacketToServer(PacketDispatcher.getPacket(ModInformation.CHANNEL, byteStream.toByteArray()));
		}catch(IOException ex) {
			System.err.append("Failed to send spaceship drop packet");
		}
	}
	
	public static void sendInterfacePacket(byte type, byte val) {
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		DataOutputStream dataStream = new DataOutputStream(byteStream);

		try {
			dataStream.writeByte((byte)1);
			dataStream.writeByte(type);
			dataStream.writeByte(val);			
			
			PacketDispatcher.sendPacketToServer(PacketDispatcher.getPacket(ModInformation.CHANNEL, byteStream.toByteArray()));
		}catch(IOException ex) {
			System.err.append("Failed to send button click packet");
		}
	}	

}
