package example.entities;

import cpw.mods.fml.common.registry.EntityRegistry;
import example.StevesInterfaces;

public class Entities {

	public static void init() {
		EntityRegistry.registerModEntity(EntitySpaceship.class, "EntitySpaceship", 0, StevesInterfaces.instance, 80, 3, true);
		EntityRegistry.registerModEntity(EntityBomb.class, "EntityBomb", 1, StevesInterfaces.instance, 80, 3, false);
	}
	
}
