package example.tileentities;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;

public class TileEntityMachine extends TileEntity implements IInventory {

	private ItemStack[] items;
	public final boolean[] customSetup;
	public int heightSetting = 20;
	
	public TileEntityMachine() {
		items = new ItemStack[3];	
		customSetup = new boolean[49];
	}
	
	@Override
	public int getSizeInventory() {
		return items.length;
	}

	@Override
	public ItemStack getStackInSlot(int i) {
		return items[i];
	}

	@Override
	public ItemStack decrStackSize(int i, int count) {
		ItemStack itemstack = getStackInSlot(i);
		
		if (itemstack != null) {
			if (itemstack.stackSize <= count) {
				setInventorySlotContents(i, null);
			}else{
				itemstack = itemstack.splitStack(count);
				onInventoryChanged();
			}
		}

		return itemstack;
	}

	@Override
	public ItemStack getStackInSlotOnClosing(int i) {
		ItemStack item = getStackInSlot(i);
		setInventorySlotContents(i, null);
		return item;
	}

	@Override
	public void setInventorySlotContents(int i, ItemStack itemstack) {
		items[i] = itemstack;
		
		if (itemstack != null && itemstack.stackSize > getInventoryStackLimit()) {
			itemstack.stackSize = getInventoryStackLimit();
		}
		
		onInventoryChanged();
	}

	@Override
	public String getInvName() {
		return "InventoryMachine";
	}

	@Override
	public boolean isInvNameLocalized() {
		return false;
	}

	@Override
	public int getInventoryStackLimit() {
		return 64;
	}

	@Override
	public boolean isUseableByPlayer(EntityPlayer entityplayer) {
		return entityplayer.getDistanceSq(xCoord + 0.5, yCoord + 0.5, zCoord + 0.5) <= 64;
	}

	@Override
	public void openChest() {}

	@Override
	public void closeChest() {}

	@Override
	public boolean isItemValidForSlot(int i, ItemStack itemstack) {
		return itemstack.itemID == Block.anvil.blockID;
	}
	
	@Override
	public void writeToNBT(NBTTagCompound compound) {
		super.writeToNBT(compound);
		
		NBTTagList items = new NBTTagList();
		
		for (int i = 0; i < getSizeInventory(); i++) {		
			ItemStack stack = getStackInSlot(i);
			
			if (stack != null) {
				NBTTagCompound item = new NBTTagCompound();
				item.setByte("Slot", (byte)i);
				stack.writeToNBT(item);
				items.appendTag(item);
			}
		}
		
		compound.setTag("Items", items);
		
		for (int i = 0; i < customSetup.length; i++) {
			compound.setBoolean("Custom" + i, customSetup[i]);
		}
		
		compound.setByte("Height", (byte)heightSetting);
	}
	
	@Override
	public void readFromNBT(NBTTagCompound compound) {
		super.readFromNBT(compound);
		
		NBTTagList items = compound.getTagList("Items");
		
		for (int i = 0; i < items.tagCount(); i++) {
			NBTTagCompound item = (NBTTagCompound)items.tagAt(i);
			int slot = item.getByte("Slot");
			
			if (slot >= 0 && slot < getSizeInventory()) {
				setInventorySlotContents(slot, ItemStack.loadItemStackFromNBT(item));
			}
		}
		
		for (int i = 0; i < customSetup.length; i++) {
			setCustomAnvil(i,  compound.getBoolean("Custom" + i));
		}
		
		heightSetting = compound.getByte("Height");
	}

	public void receiveInterfaceEvent(byte eventId, byte val) {
		switch (eventId) {
			case 0:
				switch (val) {
					case 0:
						int meta = worldObj.getBlockMetadata(xCoord, yCoord, zCoord);
						
						int type = meta / 2;
						
						int disabled = meta % 2 == 0 ? 1 : 0;
						
						int newMeta = type * 2 + disabled;		
						
						worldObj.setBlockMetadataWithNotify(xCoord, yCoord, zCoord, newMeta, 3);			
						break;
					case 1:
						int meta2 = worldObj.getBlockMetadata(xCoord, yCoord, zCoord);
						
						worldObj.setBlockMetadataWithNotify(xCoord, yCoord, zCoord, meta2 % 2, 3);
						break;
						
				}
				break;
			case 1:
				setCustomAnvil(val, !customSetup[val]);
				break;
			case 2:
				heightSetting = val;
				break;
		}
	}

	private int anvils = -1;

	public int getAnvils() {
		if (anvils == -1) {
			calculateAnvilCount();
		}
		
		return anvils;
	}
	
	private void calculateAnvilCount() {
		anvils = 0;
		for (int i = 0; i < getSizeInventory(); i++) {
			ItemStack stack = getStackInSlot(i);
			if (stack != null && isItemValidForSlot(i, stack)) {
				anvils += stack.stackSize;
			}
		}	
	}
	
	@Override
	public void onInventoryChanged() {
		super.onInventoryChanged();
		
		anvils = -1;
	}

	private int customAnvils = 0;

	public int getCustomAnvils() {
		return customAnvils;
	}
	
	public void setCustomAnvil(int i, boolean val) {
		boolean oldVal = customSetup[i];	
		customSetup[i] = val;
		
		if (oldVal && !val) {
			customAnvils--;
		}else if(!oldVal && val) {
			customAnvils++;
		}
	}

}
