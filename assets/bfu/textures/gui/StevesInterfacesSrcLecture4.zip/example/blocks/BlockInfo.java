package example.blocks;

public class BlockInfo {

	public static final String TEXTURE_LOCATION = "example";

	public static int MACHINE_ID;
	public static final String MACHINE_KEY = "Machine";
	public static final int MACHINE_DEFAULT = 2075;
	
	public static final String MACHINE_UNLOCALIZED_NAME = "sillyMachine";
	public static final String MACHINE_NAME = "Silly Machine";
	
	public static final String MACHINE_TOP = "machine_top";
	public static final String MACHINE_BOT = "machine_bottom";
	public static final String[] MACHINE_SIDES = {"machine_side", "machine_side_arrow", "machine_side_box", "machine_side_cross", "machine_side_custom"};
	public static final String MACHINE_DISABLED = "machine_disabled";
	
	public static final String MACHINE_TE_KEY = "machineTileEntity";
	
	public static int BOMB_ID;
	public static final String BOMB_KEY = "Bomb";
	public static final int BOMB_DEFAULT = 2076;
	
	public static final String BOMB_UNLOCALIZED_NAME = "wierdBomb";
	public static final String BOMB_NAME = "Weird Bomb";
	
	public static final String BOMB_TEXTURE = "bomb";
	public static final String BOMB_IDLE_TEXTURE = "bomb_idle";
	
	public static final String BOMB_TE_KEY = "bombTileEntity";
	
	
	public static int POISON_ID;
	public static final String POISON_KEY = "Poison";
	public static final int POISON_DEFAULT = 2077;
	
	public static final String POISON_UNLOCALIZED_NAME = "poisonBlock";
	public static final String POISON_NAME = "Block of Poison";
	
	public static final String POISON_TEXTURE = "poison_block";	
	public static final String POISON_PARTICLE_TEXTURE = "poison_nocolor";


}
