package example.blocks;

import net.minecraft.block.Block;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;
import example.items.ItemMachine;
import example.tileentities.TileEntityBomb;
import example.tileentities.TileEntityMachine;
public class Blocks {

	public static Block machine;
	public static Block bomb;
	public static BlockPoison poison;
	
	public static void init() {
		machine = new BlockMachine(BlockInfo.MACHINE_ID);
		GameRegistry.registerBlock(machine, ItemMachine.class, BlockInfo.MACHINE_KEY);
		
		bomb = new BlockBomb(BlockInfo.BOMB_ID);
		GameRegistry.registerBlock(bomb, BlockInfo.BOMB_KEY);
		
		poison = new BlockPoison(BlockInfo.POISON_ID);
		GameRegistry.registerBlock(poison, BlockInfo.POISON_KEY);
	}
	
	public static void addNames() {
		LanguageRegistry.addName(machine, BlockInfo.MACHINE_NAME);
		
		LanguageRegistry.addName(bomb, BlockInfo.BOMB_NAME);
		
		LanguageRegistry.addName(poison, BlockInfo.POISON_NAME);
	}
	
	
	public static void registerTileEntities() {
		GameRegistry.registerTileEntity(TileEntityBomb.class, BlockInfo.BOMB_TE_KEY);
		GameRegistry.registerTileEntity(TileEntityMachine.class, BlockInfo.MACHINE_TE_KEY);
	}
	
}
