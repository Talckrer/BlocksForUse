package example.blocks;

import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraft.world.World;
import cpw.mods.fml.common.network.FMLNetworkHandler;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import example.StevesInterfaces;
import example.tileentities.TileEntityMachine;

public class BlockMachine extends BlockContainer {

	public BlockMachine(int id) {
		super(id, Material.iron);
		
		setCreativeTab(CreativeTabs.tabRedstone);
		setHardness(2F);
		setStepSound(Block.soundMetalFootstep);
		setUnlocalizedName(BlockInfo.MACHINE_UNLOCALIZED_NAME);
	}
	
	@SideOnly(Side.CLIENT)
	private Icon topIcon;
	@SideOnly(Side.CLIENT)
	private Icon botIcon;
	@SideOnly(Side.CLIENT)
	private Icon[] sideIcons;
	@SideOnly(Side.CLIENT)	
	private Icon disableIcon;
	
	@SideOnly(Side.CLIENT)
	@Override
	public void registerIcons(IconRegister register) {
		topIcon = register.registerIcon(BlockInfo.TEXTURE_LOCATION + ":" + BlockInfo.MACHINE_TOP);
		botIcon = register.registerIcon(BlockInfo.TEXTURE_LOCATION + ":" + BlockInfo.MACHINE_BOT);
		sideIcons = new Icon[BlockInfo.MACHINE_SIDES.length];
		for (int i = 0; i < sideIcons.length; i++) {
			sideIcons[i] = register.registerIcon(BlockInfo.TEXTURE_LOCATION + ":" + BlockInfo.MACHINE_SIDES[i]);	
		}
		disableIcon = register.registerIcon(BlockInfo.TEXTURE_LOCATION + ":" + BlockInfo.MACHINE_DISABLED);			
	}
	
	@SideOnly(Side.CLIENT)
	@Override
	public Icon getIcon(int side, int meta) {
		if (side == 0) {
			return botIcon;
		}else if(side == 1) {
			return isDisabled(meta) ? disableIcon : topIcon;
		}else{
			int type = meta / 2;
			return sideIcons[type];
		}
	}
	
	private boolean isDisabled(int meta) {
		return meta % 2 == 1;
	}
	
	@Override
	public void onEntityWalking(World world, int x, int y, int z, Entity entity) {
		if (!world.isRemote && !isDisabled(world.getBlockMetadata(x, y, z))) {
			TileEntity te = world.getBlockTileEntity(x, y, z);
			if (te != null && te instanceof TileEntityMachine) {
				TileEntityMachine machine = (TileEntityMachine)te;		
				spawnAnvil(world, machine, x, y + machine.heightSetting, z);
			}
		}
	}
	
	@Override
	public void onNeighborBlockChange(World world, int x, int y, int z, int id) {
		int meta = world.getBlockMetadata(x, y, z);
		if (!world.isRemote && world.isBlockIndirectlyGettingPowered(x, y, z) && !isDisabled(meta)) {
			TileEntity te = world.getBlockTileEntity(x, y, z);
			if (te != null && te instanceof TileEntityMachine) {
				TileEntityMachine machine = (TileEntityMachine)te;
		
				switch (meta / 2) {
					case 1:
						for (int i = 0; i < 5; i++) {
							spawnAnvil(world, machine, x, y + machine.heightSetting + i, z);
						}			
						break;
					case 2:
						for (int i = -1; i <= 1; i++) {
							spawnAnvil(world, machine, x + i, y + machine.heightSetting, z - 2);
							spawnAnvil(world, machine, x + i, y + machine.heightSetting, z + 2);
							spawnAnvil(world, machine, x - 2, y + machine.heightSetting, z + i);
							spawnAnvil(world, machine, x + 2, y + machine.heightSetting, z + i);
						}				
						break;
					case 3:
						for (int i = 1; i <= 3; i++) {
							spawnAnvil(world, machine, x + i, y + machine.heightSetting, z);
							spawnAnvil(world, machine, x - i, y + machine.heightSetting, z);
							spawnAnvil(world, machine, x, y + machine.heightSetting, z + i);
							spawnAnvil(world, machine, x, y + machine.heightSetting, z - i);
						}				
						break;
					case 4:
						for (int i = 0; i < machine.customSetup.length; i++) {
							if (machine.customSetup[i]) {
								int dropX = x + i / 7 - 3;
								int dropZ = z + i % 7 - 3;
								
								spawnAnvil(world, machine, dropX, y + machine.heightSetting, dropZ);
							}						
						}
						break;
				}
			
			}
		}
	}
	
	
	private void spawnAnvil(World world, IInventory inv, int x, int y, int z) {
		if (world.isAirBlock(x, y, z)) {
			for (int i = 0; i < inv.getSizeInventory(); i++) {
				ItemStack stack = inv.getStackInSlot(i);
				if (stack != null && stack.itemID == Block.anvil.blockID) {
					inv.decrStackSize(i, 1);
					world.setBlock(x, y, z, Block.anvil.blockID);
					return;
				}
			}			
		}
	}
	
	@Override
	public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ) {
		if (!world.isRemote) {
			FMLNetworkHandler.openGui(player, StevesInterfaces.instance, 0, world, x, y, z);			
		}
	
		return true;
	}
	
	@Override
	public int damageDropped(int meta) {
		return meta;
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public void getSubBlocks(int id, CreativeTabs tab, List list) {
		for (int i = 0; i < BlockInfo.MACHINE_SIDES.length; i++) {
			list.add(new ItemStack(id, 1, i * 2));
		}
	}

	@Override
	public TileEntity createNewTileEntity(World world) {
		return new TileEntityMachine();
	}
	
	@Override
	public void breakBlock(World world, int x, int y, int z, int id, int meta) {
		TileEntity te = world.getBlockTileEntity(x, y, z);
		if (te != null && te instanceof IInventory) {
			IInventory inventory = (IInventory)te;
			
			for (int i = 0; i < inventory.getSizeInventory(); i++) {
				ItemStack stack = inventory.getStackInSlotOnClosing(i);
				
				if (stack != null) {
					float spawnX = x + world.rand.nextFloat();
					float spawnY = y + world.rand.nextFloat();
					float spawnZ = z + world.rand.nextFloat();
					
					EntityItem droppedItem = new EntityItem(world, spawnX, spawnY, spawnZ, stack);
					
					float mult = 0.05F;
					
					droppedItem.motionX = (-0.5F + world.rand.nextFloat()) * mult;
					droppedItem.motionY = (4 + world.rand.nextFloat()) * mult;
					droppedItem.motionZ = (-0.5F + world.rand.nextFloat()) * mult;
					
					world.spawnEntityInWorld(droppedItem);
				}
			}
		}
		
		super.breakBlock(world, x, y, z, id, meta);
	}
}
