package example.client.interfaces;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import example.network.PacketHandler;

@SideOnly(Side.CLIENT)
public class GuiTabHeight extends GuiTab {

	public GuiTabHeight(int id) {
		super("Height setting", id);
	}
	
	private static final GuiRectangle bar = new GuiRectangle(50, 100, 91, 6);
	private static final GuiRectangle slider = new GuiRectangle(75, 97, 6, 11);

	private int tempHeightSetting;
	private boolean isDragging;

	@Override
	public void drawBackground(GuiMachine gui, int x, int y) {
		bar.draw(gui, 0, 250);
		updateSliderPosition(gui);
		slider.draw(gui, 0, 239);
	}

	@Override
	public void drawForeground(GuiMachine gui, int x, int y) {
		gui.getFontRenderer().drawString("Height: +" + getCurrentHeight(gui), 60, 88, 0x404040);
	}
	
	@Override
	public void mouseClick(GuiMachine gui, int x, int y, int button) {
		updateSliderPosition(gui);
		if (slider.inRect(gui, x, y)) {
			isDragging = true;
			tempHeightSetting = gui.machine.heightSetting;
		}
	}
	
	@Override
	public void mouseMoveClick(GuiMachine gui, int x, int y, int button, long timeSinceClicked) {
		if (isDragging) {
			tempHeightSetting = x - gui.getLeft() - 50;
			if (tempHeightSetting < 0) {
				tempHeightSetting = 0;
			}else if(tempHeightSetting > 85) {
				tempHeightSetting = 85;
			}
		}
	}
	
	@Override
	public void mouseReleased(GuiMachine gui, int x, int y, int button) {
		if (isDragging) {
			PacketHandler.sendInterfacePacket((byte)2, (byte)tempHeightSetting);
			gui.machine.heightSetting = tempHeightSetting;
			isDragging = false;
		}
	}
	
	private void updateSliderPosition(GuiMachine gui) {
		slider.setX(50 + getCurrentHeight(gui));
	}
	
	private int getCurrentHeight(GuiMachine gui) {
		return isDragging ? tempHeightSetting : gui.machine.heightSetting;	
	}
	
}
