package example.client.interfaces;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GuiTabTest extends GuiTab {

	public GuiTabTest(int id) {
		super("Test", id);
	}

	@Override
	public void drawBackground(GuiMachine gui, int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void drawForeground(GuiMachine gui, int x, int y) {
		// TODO Auto-generated method stub
		
	}
	
}
