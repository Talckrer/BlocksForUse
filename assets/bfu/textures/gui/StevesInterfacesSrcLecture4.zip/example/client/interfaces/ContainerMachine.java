package example.client.interfaces;

import java.util.Arrays;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import example.tileentities.TileEntityMachine;

public class ContainerMachine extends Container {

	private TileEntityMachine machine;
	
	public ContainerMachine(InventoryPlayer invPlayer, TileEntityMachine machine) {
		this.machine = machine;
		
		for (int x = 0; x < 9; x++) {
			addSlotToContainer(new Slot(invPlayer, x, 8 + 18 * x, 194));
		}
		
		for (int y = 0; y < 3; y++) {
			for (int x = 0; x < 9; x++) {
				addSlotToContainer(new Slot(invPlayer, x + y * 9 + 9, 8 + 18 * x, 136 + y * 18));
			}
		}
		
		for (int x = 0; x < 3; x++) {
			addSlotToContainer(new SlotAnvil(machine, x, 8 + 18 * x, 17));
		}
	}
	
	@Override
	public boolean canInteractWith(EntityPlayer entityplayer) {
		return machine.isUseableByPlayer(entityplayer);
	}
	
	@Override
	public ItemStack transferStackInSlot(EntityPlayer player, int i) {
		Slot slot = getSlot(i);
		
		if (slot != null && slot.getHasStack()) {
			ItemStack stack = slot.getStack();
			ItemStack result = stack.copy();
			
			if (i >= 36) {
				if (!mergeItemStack(stack, 0, 36, false)) {
					return null;
				}
			}else if(stack.itemID != Block.anvil.blockID || !mergeItemStack(stack, 36, 36 + machine.getSizeInventory(), false)) {
				return null;
			}
			
			if (stack.stackSize == 0) {
				slot.putStack(null);
			}else{
				slot.onSlotChanged();
			}
			
			slot.onPickupFromSlot(player, stack);
			
			return result;
		}
		
		return null;
	}
	
	public TileEntityMachine getMachine() {
		return machine;
	}
	
	@Override
	public void addCraftingToCrafters(ICrafting player) {
		super.addCraftingToCrafters(player);
		
		for (int i = 0; i < machine.customSetup.length; i++) {
			player.sendProgressBarUpdate(this, i, machine.customSetup[i] ? 1 : 0);
		}
		
		player.sendProgressBarUpdate(this, 49, machine.heightSetting);
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public void updateProgressBar(int id, int data) {
		if (id < machine.customSetup.length) {
			machine.setCustomAnvil(id, data != 0);
		}else{
			machine.heightSetting = data;
		}
	}
	
	private boolean[] oldData = new boolean[49];
	private int oldHeight;
	
	@Override
	public void detectAndSendChanges() {
		super.detectAndSendChanges();
		
		for (Object player : crafters) {
			for (int i = 0; i < machine.customSetup.length; i++) {
				if (machine.customSetup[i] != oldData[i]) {								
					((ICrafting)player).sendProgressBarUpdate(this, i, machine.customSetup[i] ? 1 : 0);		
				}
			}
			
			if (machine.heightSetting != oldHeight) {
				((ICrafting)player).sendProgressBarUpdate(this, 49, machine.heightSetting);
			}
		}
		
		oldData = Arrays.copyOf(machine.customSetup, machine.customSetup.length);
		oldHeight = machine.heightSetting;
	}

}
