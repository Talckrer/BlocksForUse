package example.client.interfaces;

import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.ResourceLocation;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import example.blocks.Blocks;
import example.network.PacketHandler;
import example.tileentities.TileEntityMachine;

@SideOnly(Side.CLIENT)
public class GuiMachine extends GuiContainer {

	protected TileEntityMachine machine;
	private final GuiTab[] tabs;
	private GuiTab activeTab;

	public GuiMachine(InventoryPlayer invPlayer, TileEntityMachine machine) {
		super(new ContainerMachine(invPlayer, machine));
		
		this.machine = machine;
		
		xSize = 176;
		ySize = 218;
		
		tabs = new GuiTab[] {
			new GuiTabCustom(0),
			new GuiTabHeight(1),
			new GuiTabPreview(2)
		};

		activeTab = tabs[0];
	}

	private static final ResourceLocation texture = new ResourceLocation("example", "textures/gui/machine2.png");
	protected static final GuiRectangle[] rectangles;
	
	static {
		rectangles = new GuiRectangle[49];
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				rectangles[i * 7 + j] = new GuiRectangle(57 + i * 9, 70 + j * 9, 8, 8);
			}
		}
	}
	
	@Override
	protected void drawGuiContainerBackgroundLayer(float f, int x, int y) {
		GL11.glColor4f(1, 1, 1, 1);
		
		Minecraft.getMinecraft().func_110434_K().func_110577_a(texture);
		drawTexturedModalRect(guiLeft, guiTop, 0, 0, xSize, ySize);
		
		int meta = machine.worldObj.getBlockMetadata(machine.xCoord, machine.yCoord, machine.zCoord);
		int type = meta / 2;
		
		if (type != 0) {
			int srcX = 20 * (type - 1);
			int srcY = ySize;
			
			drawTexturedModalRect(guiLeft + 16, guiTop + 42, srcX, srcY, 20, 20);
		}
		
		
		float filled = machine.getAnvils() / 192F;
		int barHeight = (int)(filled * 27);
		if (barHeight > 0) {
			int srcX = xSize;
			int srcY = 27 - barHeight;
			
			drawTexturedModalRect(guiLeft + 157, guiTop + 40 + 27 - barHeight, srcX, srcY, 7, barHeight);
		}
	
		
		
		for (GuiRectangle tab : tabs) {
			int srcY = 43;
			
			if (tab == activeTab) {
				srcY += 32;
			}else if(tab.inRect(this, x, y)) {
				srcY += 16;
			}
			
			tab.draw(this, xSize, srcY);
		}
		
		activeTab.drawBackground(this, x, y);
		
		Minecraft.getMinecraft().func_110434_K().func_110577_a(TextureMap.field_110575_b);
		drawTexturedModelRectFromIcon(guiLeft + 63, guiTop + 17, Blocks.machine.getIcon(1, meta), 16, 16);
	}

	
	@Override
	protected void drawGuiContainerForegroundLayer(int x, int y) {
		fontRenderer.drawString("Silly Machine", 8, 6, 0x404040);
		
		int type = machine.worldObj.getBlockMetadata(machine.xCoord, machine.yCoord, machine.zCoord) / 2;
		
		String str;
		boolean invalid = true;
		if (type == 0) {
			str = "No type selected";
		}else{
			int count = 0;
			if (type == 1) {
				count = 5;
			}else if(type == 4) {
				count = machine.getCustomAnvils();
			}else{
				count = 12;
			}
			
			if (machine.getAnvils() >= count) {
				invalid = false;
			}
			
			str = "Requires " + count + " anvils per drop";
		}
		
		int color = invalid ? 0xD30000 : 0x404040;
		fontRenderer.drawSplitString(str, 45, 44, 100, color);
		
		
		activeTab.drawForeground(this, x, y);
		
		for (GuiTab tab : tabs) {
			tab.drawString(this, x, y, tab.getName());
		}
	}
	
	private static final String ENABLE_TEXT = "Enable";
	private static final String DISABLE_TEXT = "Disable";
	
	@Override
	public void initGui() {
		super.initGui();
		buttonList.clear();
		
		buttonList.add(new GuiButton(0, guiLeft + 80, guiTop + 14, 48, 20, 
			machine.getBlockMetadata() % 2 == 0 ? DISABLE_TEXT : ENABLE_TEXT)
		);
		
		GuiButton clearButton = new GuiButton(1, guiLeft + 130, guiTop + 14, 40, 20, "Clear");
		clearButton.enabled = machine.getBlockMetadata() / 2 != 0;
		buttonList.add(clearButton);
	}
	
	@Override
	protected void actionPerformed(GuiButton button) {
		PacketHandler.sendInterfacePacket((byte)0, (byte)button.id);
		if (button.id == 0) {
			button.displayString = button.displayString.equals(DISABLE_TEXT) ? ENABLE_TEXT : DISABLE_TEXT;
		}else if(button.id == 1) {
			button.enabled = false;
		}
	}
	
	protected int getLeft() {
		return guiLeft;
	}
	
	protected int getTop() {
		return guiTop;
	}
	
	protected void drawHoverString(List lst, int x, int y) {
		drawHoveringText(lst, x, y, fontRenderer);
	}	
	
	protected FontRenderer getFontRenderer() {
		return fontRenderer;
	}
	
	@Override
	protected void mouseClicked(int x, int y, int button) {
		super.mouseClicked(x, y, button);
		
		activeTab.mouseClick(this, x, y, button);
		
		for (GuiTab tab : tabs) {
			if (activeTab != tab) {
				if (tab.inRect(this, x, y)) {
					activeTab = tab;
					break;
				}
			}
		}
	}
	


	@Override
	protected void mouseClickMove(int x, int y, int button, long timeSinceClicked) {
		super.mouseClickMove(x, y, button, timeSinceClicked);
		
		activeTab.mouseMoveClick(this, x, y, button, timeSinceClicked);
	}
	
	@Override
	protected void mouseMovedOrUp(int x, int y, int button) {
		super.mouseMovedOrUp(x, y, button);
		
		activeTab.mouseReleased(this, x, y, button);
	}
	
}
