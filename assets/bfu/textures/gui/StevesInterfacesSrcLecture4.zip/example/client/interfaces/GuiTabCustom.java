package example.client.interfaces;

import example.network.PacketHandler;

public class GuiTabCustom extends GuiTab {

	public GuiTabCustom(int id) {
		super("Custom layout", id);
	}

	@Override
	public void drawBackground(GuiMachine gui, int x, int y) {
		int meta = gui.machine.worldObj.getBlockMetadata(gui.machine.xCoord, gui.machine.yCoord, gui.machine.zCoord);
		int type = meta / 2;
			
		if (type == 4) {
			for (int i = 0; i < GuiMachine.rectangles.length; i++) {
				GuiRectangle rect = GuiMachine.rectangles[i];
				int srcX = 176;
				
				if (rect.inRect(gui, x, y)) {
					srcX += 8;
				}
				
				rect.draw(gui, srcX, 27);
				
				if (gui.machine.customSetup[i]) {
					rect.draw(gui, 176, 35);
				}
			}
		

		}
	}

	@Override
	public void drawForeground(GuiMachine gui, int x, int y) {
		int meta = gui.machine.worldObj.getBlockMetadata(gui.machine.xCoord, gui.machine.yCoord, gui.machine.zCoord);
		int type = meta / 2;
		
		if (type == 4) {
			for (int i = 0; i < GuiMachine.rectangles.length; i++) {
				GuiRectangle rect = GuiMachine.rectangles[i];
				
				String text;
				if (gui.machine.customSetup[i]) {
					text = GuiColor.GREEN + "Active";
				}else{
					text = GuiColor.RED + "Inactive";
				}
				text += "\n" + GuiColor.YELLOW + "Click to change";
				
				rect.drawString(gui, x, y, text);
			}
		}		
	}
	
	private boolean currentMode;
	
	@Override
	public void mouseClick(GuiMachine gui, int x, int y, int button) {
		for (int i = 0; i < GuiMachine.rectangles.length; i++) {
			GuiRectangle rect = GuiMachine.rectangles[i];
			
			if (rect.inRect(gui, x, y)) {
				PacketHandler.sendInterfacePacket((byte)1, (byte)i);
				currentMode = gui.machine.customSetup[i];
				gui.machine.setCustomAnvil(i, !currentMode);
				break;
			}
		}
	}
	
	@Override
	public void mouseMoveClick(GuiMachine gui, int x, int y, int button, long timeSinceClicked) {
		for (int i = 0; i < GuiMachine.rectangles.length; i++) {
			GuiRectangle rect = GuiMachine.rectangles[i];
			
			if (gui.machine.customSetup[i] == currentMode && rect.inRect(gui, x, y)) {
				PacketHandler.sendInterfacePacket((byte)1, (byte)i);
				gui.machine.setCustomAnvil(i, !currentMode);
				break;
			}
		}
	}
	
}
