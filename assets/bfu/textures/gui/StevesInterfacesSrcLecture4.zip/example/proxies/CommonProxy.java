package example.proxies;

public class CommonProxy {

	public void initSounds() {
		
	}

	public void initRenderers() {
		
	}

}
