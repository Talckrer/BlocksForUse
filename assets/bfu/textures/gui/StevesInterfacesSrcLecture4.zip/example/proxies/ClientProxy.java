package example.proxies;

import cpw.mods.fml.client.registry.RenderingRegistry;
import example.client.RenderSpaceship;
import example.client.sounds.SoundHandler;
import example.entities.EntitySpaceship;

public class ClientProxy extends CommonProxy {

	@Override
	public void initSounds() {
		new SoundHandler();
	}

	@Override
	public void initRenderers() {
		RenderingRegistry.registerEntityRenderingHandler(EntitySpaceship.class, new RenderSpaceship());
	}	
	
}
